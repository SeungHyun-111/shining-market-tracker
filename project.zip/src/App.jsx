import { useMemo, useState } from "react";
import DashboardLayout from "./layouts/DashboardLayout";
import HeaderBar from "./components/HeaderBar";
import Top20Section from "./components/Top20Section";
import TrendSection from "./components/TrendSection";
import YearCompareSection from "./components/YearCompareSection";
import PriceSection from "./components/PriceSection";
import {
  top20Data,
  trendMap,
  yearCompareTrend,
  priceItemsMap,
} from "./data/dummyData";

function App() {
  const [period, setPeriod] = useState("7");
  const [category, setCategory] = useState("all");
  const [selectedKeyword, setSelectedKeyword] = useState("복숭아");

  const filteredTop20 = useMemo(() => {
    let data = top20Data;

    if (category !== "all") {
      data = data.filter((d) => d.category === category);
    }

    return data;
  }, [category]);

  const trendData = trendMap[selectedKeyword] || {
    monthly: [],
    weekly: [],
  };

  const priceItems = priceItemsMap[selectedKeyword] || [];

  return (
    <DashboardLayout>
      <HeaderBar
        period={period}
        setPeriod={setPeriod}
        category={category}
        setCategory={setCategory}
      />

      <Top20Section
        period={period}
        setPeriod={setPeriod}
        data={filteredTop20}
        selectedKeyword={selectedKeyword}
        onSelect={setSelectedKeyword}
      />

      <TrendSection
        selectedKeyword={selectedKeyword}
        monthlyData={trendData.monthly}
        weeklyData={trendData.weekly}
      />

      <YearCompareSection
        selectedKeyword={selectedKeyword}
        data={yearCompareTrend}
      />

      <PriceSection
        selectedKeyword={selectedKeyword}
        items={priceItems}
      />
    </DashboardLayout>
  );
}

export default App;